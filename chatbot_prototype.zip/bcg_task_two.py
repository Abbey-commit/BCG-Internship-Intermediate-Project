# Financial Insights Chatbot
responses = {
    # Microsoft Corporation
    'What is the total revenue for Microsoft Corporation?': 'The total revenue for Microsoft Corporation for the fiscal year 2022 is $198 billion, up from $168 billion in 2021.',
    # Add more responses as needed
}

def simple_chatbot(user_query):
    if user_query in responses:
        return responses[user_query]
    else:
        return 'Sorry, I can only provide information on predefined queries.'
