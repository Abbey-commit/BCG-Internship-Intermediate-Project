# Task: Develop a Financial Insights Chatbot

**Objective**: Create a simple chatbot that responds to predefined financial queries based on the analysis of financial data from 10-K documents for Microsoft Corporation, Tesla, and Apple.

## Step 1: Preparation

1. **Review Analyzed Data**:
   - Ensure you have the financial data extracted from the 10-K documents for Microsoft Corporation, Tesla, and Apple.
2. **Set Up Your Environment**:
   - Open Google Colab and create a new notebook.
   - Import the necessary libraries:
     ```python
     import pandas as pd
     ```

## Step 2: Chatbot Design and Data Preparation

1. **Define Predefined Queries**:
   - Identify common financial queries based on your analysis.
2. **Prepare Responses**:
   - Create a dictionary to map each predefined query to its corresponding response based on the analysis of the financial data.
